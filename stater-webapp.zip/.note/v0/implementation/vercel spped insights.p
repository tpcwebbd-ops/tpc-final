npm i @vercel/speed-insights

import { SpeedInsights } from "@vercel/speed-insights/next"
<SpeedInsights/> 